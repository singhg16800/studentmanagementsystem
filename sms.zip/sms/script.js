
let students = JSON.parse(localStorage.getItem("students")) || [];

const studentForm = document.getElementById("studentForm");
const studentTableBody = document.getElementById("studentTableBody");
const searchInput = document.getElementById("searchInput");

const totalStudents = document.getElementById("totalStudents");
const totalCourses = document.getElementById("totalCourses");
const activeStudents = document.getElementById("activeStudents");

const formHeading = document.getElementById("formHeading");
const submitBtn = document.getElementElement
    ? document.getElementById("submitBtn")
    : document.getElementById("submitBtn");

// Save data in browser storage
function saveData() {
    localStorage.setItem("students", JSON.stringify(students));
}

// Escape user-entered text before displaying in HTML
function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };
        return entities[char];
    });
}

// Update dashboard
function updateDashboard() {
    totalStudents.textContent = students.length;

    const courses = [...new Set(students.map(student => student.course))];
    totalCourses.textContent = courses.length;

    const activeCount = students.filter(
        student => student.status === "Active"
    ).length;

    activeStudents.textContent = activeCount;
}

// Display students in table
function displayStudents(list = students) {
    studentTableBody.innerHTML = "";

    const emptyMessage = document.getElementById("emptyMessage");

    if (list.length === 0) {
        emptyMessage.style.display = "block";
    } else {
        emptyMessage.style.display = "none";
    }

    list.forEach(student => {
        const index = students.indexOf(student);

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${escapeHTML(student.studentId)}</td>
            <td>${escapeHTML(student.name)}</td>
            <td>${escapeHTML(student.email)}</td>
            <td>${escapeHTML(student.phone)}</td>
            <td>${escapeHTML(student.course)}</td>
            <td>
                <span class="status ${student.status === "Active" ? "active" : "inactive"}">
                    ${escapeHTML(student.status)}
                </span>
            </td>
            <td>
                <button class="edit-btn" data-action="edit" data-index="${index}">
                    Edit
                </button>
                <button class="delete-btn" data-action="delete" data-index="${index}">
                    Delete
                </button>
            </td>
        `;

        studentTableBody.appendChild(row);
    });

    updateDashboard();
}

// Add or update student
studentForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const editIndex = document.getElementById("editIndex").value;

    const student = {
        studentId: document.getElementById("studentId").value.trim(),
        name: document.getElementById("studentName").value.trim(),
        email: document.getElementById("studentEmail").value.trim(),
        phone: document.getElementById("studentPhone").value.trim(),
        course: document.getElementById("studentCourse").value,
        status: document.getElementById("studentStatus").value
    };

    // Prevent duplicate student ID
    const duplicate = students.some((item, index) =>
        item.studentId.toLowerCase() === student.studentId.toLowerCase()
        && String(index) !== editIndex
    );

    if (duplicate) {
        alert("This Student ID already exists!");
        return;
    }

    if (editIndex !== "") {
        students[Number(editIndex)] = student;
        alert("Student updated successfully!");
    } else {
        students.push(student);
        alert("Student added successfully!");
    }

    saveData();
    displayStudents();
    resetForm();
});

// Edit and delete buttons
studentTableBody.addEventListener("click", function (event) {
    const button = event.target.closest("button");
    if (!button) return;

    const index = Number(button.dataset.index);
    const action = button.dataset.action;

    if (action === "edit") {
        editStudent(index);
    }

    if (action === "delete") {
        deleteStudent(index);
    }
});

// Edit student
function editStudent(index) {
    const student = students[index];
    if (!student) return;

    document.getElementById("editIndex").value = index;
    document.getElementById("studentId").value = student.studentId;
    document.getElementById("studentName").value = student.name;
    document.getElementById("studentEmail").value = student.email;
    document.getElementById("studentPhone").value = student.phone;
    document.getElementById("studentCourse").value = student.course;
    document.getElementById("studentStatus").value = student.status;

    formHeading.textContent = "Edit Student";
    submitBtn.textContent = "Update Student";

    document.getElementById("addStudentSection").scrollIntoView({
        behavior: "smooth"
    });
}

// Delete student
function deleteStudent(index) {
    const student = students[index];
    if (!student) return;

    const confirmDelete = confirm(
        `Are you sure you want to delete ${student.name}?`
    );

    if (confirmDelete) {
        students.splice(index, 1);
        saveData();
        displayStudents();
        alert("Student deleted successfully!");
    }
}

// Reset form
function resetForm() {
    studentForm.reset();
    document.getElementById("editIndex").value = "";
    formHeading.textContent = "Add New Student";
    submitBtn.textContent = "Add Student";
}

// Reset button behavior
studentForm.addEventListener("reset", function () {
    setTimeout(() => {
        document.getElementById("editIndex").value = "";
        formHeading.textContent = "Add New Student";
        submitBtn.textContent = "Add Student";
    }, 0);
});

// Search students
searchInput.addEventListener("input", function () {
    const searchText = this.value.toLowerCase().trim();

    const filteredStudents = students.filter(student =>
        student.studentId.toLowerCase().includes(searchText) ||
        student.name.toLowerCase().includes(searchText) ||
        student.email.toLowerCase().includes(searchText) ||
        student.course.toLowerCase().includes(searchText) ||
        student.phone.toLowerCase().includes(searchText) ||
        student.status.toLowerCase().includes(searchText)
    );

    displayStudents(filteredStudents);
});

// Initial load
displayStudents();
